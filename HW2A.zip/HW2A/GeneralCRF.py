__author__ = 'mhjang'

import numpy as np
import itertools
import math



charMap = {0:'e', 1:'t', 2:'a', 3:'i', 4:'n', 5:'o', 6:'s', 7:'h', 8:'r', 9:'d'}
invCharMap = {'e':0, 't':1, 'a':2, 'i':3, 'n':4, 'o':5, 's':6, 'h':7, 'r':8, 'd':9}

featureParams = np.genfromtxt('model/feature-params.txt')
transitiveParams = np.genfromtxt('model/transition-params.txt')

# for problem 2.1
def cliquePotential(features):
    psimaps = [np.zeros((10,10)) for i in range(len(features)-1)]
    # for cluster 1
    # i: index of y0
    # j: index of y1
    for k in range(len(features)-1):
        for i in range(10):
            for j in range(10):
                if k != len(features)-2:
                    psimaps[k][i][j] = sum(featureParams[i] * features[k]) + transitiveParams[i][j]
                else:
                    psimaps[k][i][j] = sum(featureParams[i] * features[k]) + sum(featureParams[j] * features[k+1]) + transitiveParams[i][j]
  #  printETRtable(psimaps[-1])
    return psimaps



# for problem 2.2
def computeMessagePassing(features):
    potentialMap = cliquePotential(features)
    cliqueNumber = len(potentialMap)
    forwardMessages = [np.zeros(10) for i in range((cliqueNumber-1))]
    backwardMessages = [np.zeros(10) for i in range((cliqueNumber-1))]

    # very first forward message
    for i in range(10):
        sum = 0.0
        for j in range(10):
            sum = sum + math.exp(potentialMap[0][j][i])
    #    print(charMap[i] + "\t" + str(math.log(sum)))
        forwardMessages[0][i] = math.log(sum)


    # rest of the chains
    for k in range(1, len(forwardMessages)):
        for i in range(10):
            sum = 0.0
            for j in range(10):
                sum = sum + math.exp(potentialMap[k][j][i] + forwardMessages[k-1][j])
            forwardMessages[k][i] = math.log(sum)


   # very first backward message
    for i in range(10):
        sum = 0.0
        for j in range(10):
            sum = sum + math.exp(potentialMap[cliqueNumber-1][i][j])

        backwardMessages[cliqueNumber-2][i] = math.log(sum)

   # rest of the chains
    for k in range(cliqueNumber-3,-1,-1):
     for i in range(10):
        sum = 0.0
        for j in range(10):
            sum = sum + math.exp(potentialMap[k+1][i][j] + backwardMessages[k+1][j])
        backwardMessages[k][i] = math.log(sum)

    return [forwardMessages, backwardMessages]


# for problem 2.3
def computeLogBeliefs(feature):
    potentialMap = cliquePotential(feature)
    messages = computeMessagePassing(feature)
    forwardMessages = messages[0]
    backwardMessages = messages[1]
    cliqueNumber = len(potentialMap)

    beliefs = [np.zeros((10,10)) for i in range((cliqueNumber))]


    # belief for the first cluster
   # print("B(Y1, Y2)")
    for i in range(10):
        sum = 0.0
        for j in range(10):
            beliefs[0][i][j] = (potentialMap[0][i][j]) + backwardMessages[0][j]

    # for the rest ...
    for k in range(1, cliqueNumber-1):
        for i in range(10):
            sum = 0.0
            for j in range(10):
                beliefs[k][i][j] = potentialMap[k][i][j] + forwardMessages[k-1][i] + backwardMessages[k][j]
    #    print(charMap[i] + "\t" + str(belief_2_3[i]))
  #  printETtable(belief_2_3)

    # belief for the last cluster
#    print("B(Y3, Y4)")
    # delta_{3->2}(Y3) = log \sum_{y4}(exp(Y3, Y4)
    for i in range(10):
        sum = 0.0
        for j in range(10):
            beliefs[cliqueNumber-1][i][j] =  potentialMap[cliqueNumber-1][i][j] + forwardMessages[cliqueNumber-2][i]
#        print(charMap[i] + "\t" + str(belief_3_4[i]))
  #  printETtable(beliefs[-1])
    return beliefs


# for problem 2.5
def predictStringWithMarginals(feature):
    beliefs = computeLogBeliefs(feature)
    expBeliefs = [np.exp(belief) for belief in beliefs]
    marginal_probs = [belief / np.sum(belief, axis=None) for belief in expBeliefs]

    predictedWord = [charMap[np.argmax(np.max(marginals, axis = 1))] for marginals in marginal_probs]
    predictedWord.append(charMap[np.argmax(np.max(marginal_probs[-1], axis = 0))])
 #   print(''.join(predictedWord))
    return ''.join(predictedWord)

def main():

    f = open('data/test_words.txt', 'r')
    testWords = f.readlines()
    accuracy = np.zeros(200);
    correct = 0
    incorrect =0
    for i in range(1,201):
        filename = 'data/test_img' + str(i) + ".txt"
        features = np.genfromtxt(filename)
        word = (str)(predictStringWithMarginals(features))
        trueWord = testWords[i-1]
        bitDifference = 0
        for k in range(len(word)):
            if word[k] == trueWord[k]:
                correct += 1
                bitDifference +=1
            else:
                incorrect += 1
#        accuracy[i-1] = correct/len(word)
 #       print(word + "\t" + trueWord + "\t" + (str)(bitDifference))
#    print(str(np.sum(accuracy)/200))
    print((str)((correct)/(correct + incorrect)))


if __name__ == "__main__":
    main()